##########
Change Log
##########

Version 3.1.x
=============

Release Date: Unreleased

-   New Translations

-   Updated Translations

    -   portuguese-brazilian
    -   ukrainian

Version 3.1.0
=============

Release Date: Jul 26, 2016

-   New Translations

    -   serbian
    
-   Updated Translations

    -   german
    -   hindi
    -   italian
    -   slovenian
    -   swedish

Version 3.0.6
=============

Release Date: Mar 21, 2016

-   Housekeeping

    - Synchronize release # with CI3.

Version 3.0.5
=============

Release Date: Mar 11, 2016

-   New Translations

    -   bengali

Version 3.0.4
=============

Release Date: Jan 13, 2016

-   Housekeeping

    -   Updated copyright dates for 2016.

-   New Translations

    -   armenian
    -   greek
    -   slovenian

-   Updated Translations

    -   filipino
    -   vietnamese

Version 3.0.3
=============

Release Date: Oct 31, 2015

- No changes. Updated version # to sync with framework.

Version 3.0.2
=============

Release Date: Oct 8, 2015

-   Enhancements

    -   MY_Lang (optional) can provide automatic translation fallbacks.

-   Updated Translations

    -   arabic
    -   german
    -   hindi
    -   persian
    -   portuguese-brazilian
    -   romanian
    -   simplified-chinese
    -   thai
    -   vietnamese

-   New Translations

    -   latvian
    -   slovak 

Version 3.0.0
=============

Release Date: March 30, 2015

Initial "official" release, with settings consistent with CodeIgniter 3.0.0

